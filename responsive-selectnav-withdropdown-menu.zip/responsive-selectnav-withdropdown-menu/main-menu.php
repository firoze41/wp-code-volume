
		<!-- menu area start -->
		<div class="cssmenu">
			<div class="container">
				<div class="row">
					<div class="col-md-12 col-sm-12 col-lg-12">
						<div class="">
							<?php wp_nav_menu( array( 
							'theme_location' => 'bishop_menu',
							'menu_class'=> '',
							'menu_id' => 'nav',
							'echo'  => true,
							) ); ?>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- menu area end -->